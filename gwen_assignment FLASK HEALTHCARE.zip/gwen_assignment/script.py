# Flask Web Application for Data Collection
from flask import Flask, render_template, request, jsonify
from flask_pymongo import PyMongo
import pandas as pd
import json
import matplotlib.pyplot as plt
import seaborn as sns
import os

app = Flask(__name__)

# MongoDB Configuration
app.config['MONGO_URI'] = 'mongodb://localhost:27017/surveyDB'
mongo = PyMongo(app)

db = mongo.db

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    data = request.json
    db.users.insert_one(data)
    return jsonify({"message": "Data saved successfully"}), 201

if __name__ == '__main__':
    app.run(debug=True)

# Data Processing
class User:
    def __init__(self, age, gender, income, expenses):
        self.age = age
        self.gender = gender
        self.income = income
        self.expenses = expenses

    def to_dict(self):
        return {"age": self.age, "gender": self.gender, "income": self.income, "expenses": self.expenses}

# Extract Data and Save to CSV
def extract_and_save():
    users = list(db.users.find({}, {'_id': 0}))
    df = pd.DataFrame(users)
    df.to_csv('survey_data.csv', index=False)

# Data Visualization
def visualize_data():
    df = pd.read_csv('survey_data.csv')
    
    # Income distribution by Age
    plt.figure(figsize=(8,6))
    sns.barplot(x='age', y='income', data=df)
    plt.title('Income by Age')
    plt.savefig('income_by_age.png')
    
    # Gender distribution across spending
    plt.figure(figsize=(8,6))
    sns.countplot(x='gender', data=df)
    plt.title('Gender Distribution')
    plt.savefig('gender_distribution.png')

    print("Visualizations saved.")

# AWS Deployment Instructions
# 1. Create an EC2 instance and install Flask & MongoDB
# 2. Clone this repository and run `python app.py`
# 3. Set up security groups to allow traffic on the Flask app port

# Running the functions
if __name__ == '__main__':
    extract_and_save()
    visualize_data()
